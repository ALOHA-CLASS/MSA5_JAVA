package Day10.Ex03_AnonymousObject;

public class Person {

	String name;
	int age;
	
	void work() {
		System.out.println("일을 합니다.");
	}
}
