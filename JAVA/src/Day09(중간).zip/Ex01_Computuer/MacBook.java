package Day09.Ex01_Computuer;

public class MacBook extends Laptop {

	@Override
	public void typing() {
		System.out.println("MacBook - typing");
	}

}
