package Day05.Class;

public class Pikachu {
	
	// 클래스 	: 객체를 정의하는 설계도
	// 멤버 		: 변수, 메소드
	
	// 변수
	public int energy;
	public String type;
	
	// 메소드
	// - 접근지정자 반환타입 메소드명( 매개변수 ) {} 
	public String aAttack() {
		return "십만볼트";
	}
	
	public String bAttack() {
		return "전광석화";
	}

}
